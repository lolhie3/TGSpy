import asyncio
from aiogram import Bot, Dispatcher
from routers.main import router
import logging

logging.basicConfig(level="INFO", filename="tgspy.log", filemode='w',
                    format="%(asctime)s %(levelname)s %(message)s")

# Запуск бота
async def main():
    bot_api = "6546423329:AAGFr1A7tzDyL8udr8T7fxeom5cWjMgTFzY"
    bot = Bot(token=bot_api, parse_mode="Markdown")
    dp = Dispatcher()
    dp.include_router(router)
    # Запускаем бота и пропускаем все накопленные входящие
    # Да, этот метод можно вызвать даже если у вас поллинг
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())